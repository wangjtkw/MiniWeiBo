# Experimental Implementation for Animated Images

This is an experimental new animation implementation that is still work in progress.
The APIs & design might change significantly in the future.
