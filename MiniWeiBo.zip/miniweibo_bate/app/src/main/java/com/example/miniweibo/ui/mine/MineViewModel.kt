package com.example.miniweibo.ui.mine

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.miniweibo.bean.Resource
import com.example.miniweibo.bean.UserInfoBean
import com.example.miniweibo.datasource.UserInfoDataSource
import com.example.miniweibo.sdk.SDKUtil
import javax.inject.Inject

class MineViewModel @Inject constructor(userInfoDataSource: UserInfoDataSource) : ViewModel() {

    val user: LiveData<Resource<UserInfoBean>> = userInfoDataSource.getUserInfo(
        viewModelScope,
        SDKUtil.getSDKUtil().getAccessTokenBean().uid,
        SDKUtil.getSDKUtil().getAccessTokenBean().accessToken
    )
}