package com.example.miniweibo.bean

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
